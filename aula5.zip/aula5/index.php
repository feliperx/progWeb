<html>
    <head>
        <title>Forms</title>
    </head>
    <body> 
        <h2>Escolha o tipo de cadastro:</h2>
        <a href="./formPessoa.php">Pessoa</a><br>
        <a href="./formInstituicao.php">Instituicao</a><br>
        <a href="./formSetor.php">Setor</a><br>
        <a href="./formLotacao.php">Lotacao</a><br>
    </body>
</html>


